import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiplicaciones',
  templateUrl: './multiplicaciones.component.html',
  styleUrls: ['./multiplicaciones.component.css']
})
export class MultiplicacionesComponent implements OnInit {
numero1:number=0;
numero2:number=0;
total:number=0;

  constructor() { }

  multiplicar(){
    this.total = this.numero1 * this.numero2;
  }
  ngOnInit(): void {
  }

}
