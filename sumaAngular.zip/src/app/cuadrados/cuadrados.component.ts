import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cuadrados',
  templateUrl: './cuadrados.component.html',
  styleUrls: ['./cuadrados.component.css']
})
export class CuadradosComponent implements OnInit {
numero:number = 0;
totalCuadrado:number = 0;

  constructor() { }

  cuadrado(){
    this.totalCuadrado = this.numero * this.numero;
  }

  ngOnInit(): void {
  }

}
