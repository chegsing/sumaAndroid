import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sumas',
  templateUrl: './sumas.component.html',
  styleUrls: ['./sumas.component.css']
})
export class SumasComponent implements OnInit {
numero1:string = "";
numero2:string = "";
total:number = 0;

  constructor() { }

  sumar(){
    this.total = parseInt(this.numero1) + parseInt(this.numero2);
  }

  ngOnInit(): void {
  }

}
